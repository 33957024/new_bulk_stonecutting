package org.vee.bulk_stonecutting.mixin.client;

import net.minecraft.class_11910;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_3971;
import net.minecraft.class_465;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.vee.bulk_stonecutting.client.ModConfig;

/// Checks for a shift click in the output slot of a stonecutter, and if the checkbox is enabled, re-places another input stack.
@Mixin(class_312.class)
public class StonecutterMouseMixin {
    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void onMouseButton(long window, class_11910 input, int action, CallbackInfo ci) {
        class_310 client = class_310.method_1551();

        // Make sure player is in game and left-clicked with l shift
        if(client.field_1755 == null || client.field_1724 == null) return;
        class_746 player = client.field_1724;
        if(input.comp_4801() != 0) return;
        if(action != 1) return;
        if(GLFW.glfwGetKey(client.method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) != GLFW.GLFW_PRESS) return;

        // Verify current screen is the stone cutter's
        if(!(client.field_1755 instanceof class_465<?> activeScreen)) return;
        if(!(activeScreen.method_17577() instanceof class_3971 scHandler)) return;

        // id 0 is input, id 1 is output ONLY on stone cutter screen
        class_1735 hoveredSlot = ((HandledScreenAccessor)activeScreen).getFocusedSlot();
        if(hoveredSlot == null || hoveredSlot.field_7874 != 1) return;
        if(!hoveredSlot.method_7681()) return;

        if(client.field_1761 == null) return;
        class_1703 handler = player.field_7512;

        boolean isMassCraftEnabled = ModConfig.isMassCraftCheckEnabled();
        if(!isMassCraftEnabled) return;

        class_1799 inputStack = handler.method_7611(0).method_7677();
        if(inputStack.method_7960()) return;

        int invSlot = -1;
        for(int i = 0; i < player.method_31548().method_67533().size(); i++) {
            class_1799 stack = player.method_31548().method_67533().get(i);
            // Check if the item is the same
            if (stack.method_7909() == inputStack.method_7909()) {
                invSlot = i;
                // If the stack isn't a max stack, keep checking in case we do find a max stack
                if(stack.method_7947() >= stack.method_7914())
                    break;
            }
        }
        // If no stacks found, return
        if(invSlot == -1) return;
        invSlot = getScreenHandlerSlot(invSlot);

        int recipeSelected = scHandler.method_17862();

        if(isInventoryFull(player.method_31548())) {
            for(int i = 0; i < inputStack.method_7914(); i++) {
                client.field_1761.method_2906(scHandler.field_7763, hoveredSlot.field_7874, 0, class_1713.field_7795, client.field_1724);
            }
        } else {
            // Do the regular shift+left click action
            client.field_1761.method_2906(scHandler.field_7763, hoveredSlot.field_7874, 0, class_1713.field_7794, client.field_1724);
        }


        // Grab new stack
        client.field_1761.method_2906(scHandler.field_7763, invSlot, 0, class_1713.field_7790, client.field_1724);

        // Place in stone cutter if it was grabbed properly
        if(!scHandler.method_34255().method_7960()) {
            client.field_1761.method_2906(scHandler.field_7763, 0, 0, class_1713.field_7790, client.field_1724);
        }

        // Click the recipe button again
        client.field_1761.method_2900(scHandler.field_7763, recipeSelected);

        ci.cancel();
    }

    @Unique
    private int getScreenHandlerSlot(int invSlot) {
        if (invSlot < 9) {
            invSlot += 27;
        } else {
            invSlot -= 9;
        }
        invSlot += 2;
        return invSlot;
    }

    @Unique
    private boolean isInventoryFull(class_1661 inventory) {
        for(class_1799 stack : inventory.method_67533()) {
            if(stack.method_7960()) return false;
        }
        return true;
    }
}
