package org.vee.bulk_stonecutting.mixin.client;

import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3971;
import net.minecraft.class_3979;
import net.minecraft.class_4286;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.vee.bulk_stonecutting.client.ModConfig;

/// Adds a checkbox to the stonecutter gui that can be checked to enable/disable the bulk stone cutting functionality
@Mixin(class_3979.class)
public abstract class StonecutterScreenMixin extends class_465<class_3971> {
    @Unique
    private class_4286 massCraftCheckbox;
    @Unique
    private final int X_OFFSET = -82;
    @Unique
    private final int Y_OFFSET = -96;

    public StonecutterScreenMixin(class_3971 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        massCraftCheckbox = class_4286.method_54787(class_2561.method_43470("Mass crafting"), client.field_1772)
                .method_54794(ModConfig.isMassCraftCheckEnabled())
                .method_54791(((checkbox, checked) -> ModConfig.setMassCraftCheckEnabled(checked)))
                .method_54788();
        this.method_37063(massCraftCheckbox);

        client.execute(() -> {
            int newX = client.method_22683().method_4486()/2 + X_OFFSET;
            int newY = client.method_22683().method_4502()/2 + Y_OFFSET;
            massCraftCheckbox.method_48229(newX, newY);
        });
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if(client == null) return;

        int newX = client.method_22683().method_4486()/2 + X_OFFSET;
        int newY = client.method_22683().method_4502()/2 + Y_OFFSET;

        if(massCraftCheckbox.method_46426() != newX || massCraftCheckbox.method_46427() != newY) {
            massCraftCheckbox.method_48229(newX, newY);
        }
    }


}